* Factor Analyzer and Neurolab libraries have been corrected for compatibility with new versions of other libraries along with Jupyter Notebook
* A revised Python code in Jupyter Notebook for Covid 19 Data Analysis has been created
